# Testing The Json Interface

## Using Device Explorer/Azure Portal

- Clone that latest C# SDK/Go to Azure Portal -&gt; you device
- Start the device agent.
- Paste the json in the desired properties section.
- Apply/Save
- Verify the output in the reported properties section.

## Using The DM Mock Portal Application

- Start the device agent
- Deploy a configuration.
- Get the reported properties.

## Using DMValidator

- Write new test cases.

----

[Development Scenario](../development-scenario.md) | [Plug-in Creation](developer-plugin-creation.md)