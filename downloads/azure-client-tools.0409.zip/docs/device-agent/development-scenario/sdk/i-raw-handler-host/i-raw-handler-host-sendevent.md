# IRawHandlerHost::SendEvent()

### Signature

<pre>
public:
    virtual void SendEvent(
        const std::string& id,
        const std::string& eventName,
        const Json::Value& value) = 0;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [IRawHandler](i-raw-handler-host.md)