# IRawHandlerHost::GetMdmServer()

### Signature

<pre>
public:
    virtual std::shared_ptr<IMdmServer> GetMdmServer() const = 0;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [IRawHandler](i-raw-handler-host.md)