# MdmHandlerBase::SetHandlerHost()

### Signature

<pre>
public:
    void SetHandlerHost(
        std::shared_ptr<IRawHandlerHost> iPluginHost);
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [MdmHandlerBase](mdm-handler-base.md)
