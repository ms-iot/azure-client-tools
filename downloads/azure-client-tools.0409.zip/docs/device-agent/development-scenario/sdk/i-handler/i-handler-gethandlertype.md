# IRawHandler::GetHandlerType()

### Signature

<pre>
public:
    virtual std::string GetHandlerType() const = 0;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [IHandler](i-handler.md)
