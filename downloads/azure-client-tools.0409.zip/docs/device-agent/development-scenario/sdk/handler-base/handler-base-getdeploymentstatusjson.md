# HandlerBase::GetDeploymentStatusJson()

### Signature

<pre>
Json::Value GetDeploymentStatusJson() const;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [HandlerBase](handler-base.md)
