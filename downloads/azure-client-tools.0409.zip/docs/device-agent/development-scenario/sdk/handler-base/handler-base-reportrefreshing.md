# HandlerBase::ReportRefreshing()

### Signature

<pre>
void ReportRefreshing();
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [HandlerBase](handler-base.md)
