# HandlerBase::GetId()

### Signature

<pre>
std::string GetId() const;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [HandlerBase](handler-base.md)
