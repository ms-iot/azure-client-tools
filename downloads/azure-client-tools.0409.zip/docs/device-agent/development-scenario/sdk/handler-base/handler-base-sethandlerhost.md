# HandlerBase::SetHandlerHost()

### Signature

<pre>
void SetHandlerHost(
    std::shared_ptr<IRawHandlerHost> iHandlerHost);
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [HandlerBase](handler-base.md)
