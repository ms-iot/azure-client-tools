# HandlerBase::SendEvent()

### Signature

<pre>
void SendEvent(
    std::string eventName,
    Json::Value& eventObject);
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [HandlerBase](handler-base.md)
