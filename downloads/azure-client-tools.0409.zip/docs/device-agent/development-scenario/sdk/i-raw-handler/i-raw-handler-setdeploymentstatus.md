# IRawHandler::SetDeploymentStatus()

### Signature

<pre>
public:
    virtual void SetDeploymentStatus(
        DeploymentStatus deploymentStatus) = 0;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [IRawHandler](i-raw-handler.md)
