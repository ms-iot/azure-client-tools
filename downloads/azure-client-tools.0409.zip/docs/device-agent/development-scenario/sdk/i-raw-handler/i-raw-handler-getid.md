# IRawHandler::GetId()

### Signature

<pre>
public:
    virtual std::string GetId() const = 0;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [IRawHandler](i-raw-handler.md)
