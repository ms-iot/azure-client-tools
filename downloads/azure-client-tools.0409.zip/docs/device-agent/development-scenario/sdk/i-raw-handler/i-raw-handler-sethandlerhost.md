# IRawHandler::SetHandlerHost()

### Signature

<pre>
public:
    virtual void SetHandlerHost(
        std::shared_ptr<IRawHandlerHost> iPluginHost) = 0;
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [IRawHandler](i-raw-handler.md)
