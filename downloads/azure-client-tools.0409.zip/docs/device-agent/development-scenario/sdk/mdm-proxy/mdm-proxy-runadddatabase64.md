# MdmProxy::RunAddDataBase64()

### Signature

<pre>
public:
    void RunAddDataBase64(
        const std::string& path,
        const std::string& value);
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [MdmProxy](mdm-proxy.md)
