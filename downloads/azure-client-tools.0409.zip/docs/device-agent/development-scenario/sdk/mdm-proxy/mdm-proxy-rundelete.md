# MdmProxy::RunDelete()

### Signature

<pre>
public:
    void RunDelete(
        const std::string& path);
</pre>

### Purpose

### Timing

### Parameters

### Sample Override

----

[Development Scenario Walk-Through](../../../development-scenario.md) | [Authoring New Plugins](../../developer-plugin-creation.md) | [MdmProxy](mdm-proxy.md)
