// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once

#define FactoryResetCmdHandlerId "factoryResetCmd"
#define JsonFactoryResetClearTpm "clearTpm"
#define JsonFactoryResetPartitionGuid "partitionGuid"
