// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once

namespace Microsoft { namespace Azure { namespace DeviceManagement { namespace Common {

    static const long ErrorInvalidJsonFormat = -1;
    static const long ErrorMissingXmlPath = -2;

    // Use the IoTDeviceAgentRoot to store registry keys
    #define IoTDeviceAgentRegistryRoot L"Software\\Microsoft\\IoTDeviceAgent"

}}}}
