// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once

#define PLUGIN_CREATE_REQUEST "Create Request"
#define PLUGIN_CREATE_SUCCESS_RESPONSE "Plugin Create Succeeded"
#define PLUGIN_CREATE_FAILED_RESPONSE "Plugin Create Failed"