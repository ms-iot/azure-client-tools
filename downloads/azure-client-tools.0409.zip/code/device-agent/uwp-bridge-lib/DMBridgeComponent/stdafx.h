// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once

// Wrapper for "Shared Utilities" which uses stdafx
#include "pch.h"
