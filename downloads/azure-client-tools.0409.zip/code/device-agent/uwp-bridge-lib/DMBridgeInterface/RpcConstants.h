// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once

#define RPC_PROTOCOL_SEQUENCE L"ncalrpc"
#define RPC_ENDPOINT L"DmBridgeRpcEndpoint"