// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include "stdafx.h"

#include "azure_c_shared_utility/crt_abstractions.h"
#include "azure_c_shared_utility/macro_utils.h"
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/platform.h"
#include "iothub_client.h"
#include "iothub_device_client.h"
#include "iothub_module_client.h"
#include "iothub_client_options.h"
#include "iothub_device_client.h"
#include "iothub_message.h"
#include "iothubtransportamqp.h"

#include "AzureRawHost.h"

#include "..\Handlers\ClearReportedCmdHandler.h"
#include "..\Handlers\DeviceSchemasHandler.h"
#include "../../common/plugins/PluginInterfaces.h"

using namespace DMUtils;
using namespace DMCommon;
using namespace std;

namespace Microsoft { namespace Azure { namespace DeviceManagement { namespace Client {

    shared_ptr<AzureRawHost> AzureRawHost::_this;
    shared_ptr<IMdmServer> AzureRawHost::_mdmServer;
    recursive_mutex AzureRawHost::_lock;
    recursive_mutex AzureRawHost::_azureSDKLock;
    recursive_mutex AzureRawHost::_invokeLock;

    AzureRawHost::AzureRawHost() :
        _deviceClientHandle(NULL),
        _moduleClientHandle(NULL),
        _connected(false),
        _pendingSends(0)
    {
        _reportedSectionsSummary = make_shared<ReportedSummary>();
    }

    std::shared_ptr<AzureRawHost> AzureRawHost::GetInstance()
    {
        LockGuard lk(&_lock);

        if (_this == nullptr)
        {
            _this = shared_ptr<AzureRawHost>(new AzureRawHost());
        }

        return _this;
    }

    void AzureRawHost::SetServiceParameters(
        std::shared_ptr<ServiceParameters> serviceParameters)
    {
        _serviceParameters = serviceParameters;
    }

    void AzureRawHost::SetMdmServer(
        shared_ptr<IMdmServer> mdmServer)
    {
        _mdmServer = mdmServer;
    }

    shared_ptr<IMdmServer> AzureRawHost::GetMdmServer() const
    {
        return _mdmServer;
    }
    
    Json::Value AzureRawHost::BuildHandlerConfig(
        const string& handlerId)
    {
        Json::Value handlerConfig(Json::objectValue);
        handlerConfig[JsonTextLogFilesPath] = _serviceParameters->GetLogFilePath();
        handlerConfig[JsonPluginsDataPath] = _serviceParameters->GetPluginsDataPath();

        Json::Value handlerParameters;
        if (_serviceParameters->GetHandlerParameters(handlerId, handlerParameters))
        {
            vector<string> keys = handlerParameters.getMemberNames();
            for (const string& key : keys)
            {
                handlerConfig[key] = handlerParameters[key];
            }
        }

        return handlerConfig;
    }

    void AzureRawHost::InitializeDeviceConnection(
        IOTHUB_DEVICE_CLIENT_LL_HANDLE clientHandle)
    {
        _deviceClientHandle = clientHandle;

        IOTHUB_CLIENT_RESULT result = IoTHubDeviceClient_LL_SetDeviceMethodCallback(_deviceClientHandle, OnDirectMethodInvoked, this);
        if (result != IOTHUB_CLIENT_OK)
        {
            throw DMException(DMSubsystem::IotHub, result, "IoTHubDeviceClient_LL_SetDeviceMethodCallback failed!");
        }

        result = IoTHubDeviceClient_LL_SetDeviceTwinCallback(_deviceClientHandle, OnDeviceTwinReceived, this);
        if (result != IOTHUB_CLIENT_OK)
        {
            throw DMException(DMSubsystem::IotHub, result, "IoTHubDeviceClient_LL_SetDeviceTwinCallback failed!");
        }
    }

    void AzureRawHost::InitializeModuleConnection(
        IOTHUB_MODULE_CLIENT_LL_HANDLE moduleHandle)
    {
        _moduleClientHandle = moduleHandle;

        IOTHUB_CLIENT_RESULT result = IoTHubModuleClient_LL_SetModuleMethodCallback(_moduleClientHandle, OnDirectMethodInvoked, this);
        if (result != IOTHUB_CLIENT_OK)
        {
            throw DMException(DMSubsystem::IotHub, result, "IoTHubModuleClient_LL_SetModuleMethodCallback failed!");
        }

        result = IoTHubModuleClient_LL_SetModuleTwinCallback(_moduleClientHandle, OnDeviceTwinReceived, this);
        if (result != IOTHUB_CLIENT_OK)
        {
            throw DMException(DMSubsystem::IotHub, result, "IoTHubModuleClient_LL_SetModuleTwinCallback failed!");
        }
    }

    void AzureRawHost::RegisterStaticHandler(
        std::shared_ptr<IRawHandler> handler)
    {
        TRACELINEP(LoggingLevel::Verbose, "Registering: ", handler->GetId().c_str());

        if (_rawHandlerMap.find(handler->GetId()) != _rawHandlerMap.end())
        {
            return;
        }

        handler->SetHandlerHost(_this);

        // Store in a handlerInfo struct...
        shared_ptr<RawHandlerInfo> rawHandlerInfo = make_shared<RawHandlerInfo>();
        rawHandlerInfo->_state = RawHandlerState::eInactive;
        rawHandlerInfo->_rawHandler = handler;

        _rawHandlerMap[handler->GetId()] = rawHandlerInfo;
    }

    void AzureRawHost::RegisterStaticHandlers()
    {
        RegisterStaticHandler(make_shared<ClearReportedCmdHandler>(
            [&](vector<string>& handlerIds) {
                GetHandlerIds(handlerIds);
            },
            [&](const Json::Value& reportedProperties) {
                ReportAll(reportedProperties);
            }));

        RegisterStaticHandler(make_shared<DeviceSchemasHandler>(&_rawHandlerMap));
    }

    void AzureRawHost::SetHardwareIds(
        std::shared_ptr<std::map<std::string, std::vector<std::string>>> handlersHardwareIds)
    {
        // Raw doesn't support hardware enumeration.
        _handlersHardwareIds = handlersHardwareIds;
    }

    void AzureRawHost::RegisterDynamicHandler(
        shared_ptr<IPlugin> plugin,
        const string& handlerId)
    {
        if (_rawHandlerMap.find(handlerId) != _rawHandlerMap.end())
        {
            return;
        }

        shared_ptr<IRawHandler> handler = plugin->CreateRawHandler(handlerId);

        // Set callbacks and register...
        handler->SetHandlerHost(_this);

        // Store in a handlerInfo struct...
        shared_ptr<RawHandlerInfo> rawHandlerInfo = make_shared<RawHandlerInfo>();
        rawHandlerInfo->_state = RawHandlerState::eInactive;
        rawHandlerInfo->_rawHandler = handler;

        _rawHandlerMap[handlerId] = rawHandlerInfo;
    }

    void AzureRawHost::UnregisterDynamicHandler(
        const string& handlerId)
    {
        TRACELINEP(LoggingLevel::Verbose, "Unregistering Id   : ", handlerId.c_str());
        TRACELINE(LoggingLevel::Verbose, "Unregistering Type : raw");

        auto it = _rawHandlerMap.find(handlerId);
        if (it != _rawHandlerMap.end())
        {
            _rawHandlerMap.erase(handlerId);
        }
    }

    void AzureRawHost::Report(
        const std::string& handlerId,
        DeploymentStatus deploymentStatus,
        const Json::Value& value)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        LockGuard lk(&_azureSDKLock);

        // Update the summary object
        _reportedSectionsSummary->SetSectionStatus(handlerId, deploymentStatus);

        // Combine the summary object and the result of this configuration into one transactions and submit them......
        Json::Value reportedProperties(Json::objectValue);
        reportedProperties[_reportedSectionsSummary->GetId()] = _reportedSectionsSummary->ToJsonObject();
        reportedProperties[handlerId] = value;
        ReportAll(reportedProperties);
    }

    void AzureRawHost::GetHandlerIds(vector<string>& handlerIds)
    {
        handlerIds.clear();

        for (RawHandlerMapType::const_iterator handlerIt = _rawHandlerMap.cbegin(); handlerIt != _rawHandlerMap.cend(); ++handlerIt)
        {
            handlerIds.emplace_back(handlerIt->first);
        }
    }

    void AzureRawHost::ReportAll(const Json::Value& partialReportedPropertiesObject)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        ReportAll(partialReportedPropertiesObject.toStyledString());
    }

    void AzureRawHost::ReportAll(const string& partialReportedPropertiesString)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        LockGuard lk(&_azureSDKLock);

        // ToDo: Temporary Synchronization
        if (!_connected)
        {
            TRACELINE(LoggingLevel::Warning, "Disregarding report because agent is disconnecting...");
            // ToDo: Notify the handler that it shouldn't have call report.
            return;
        }

        ++_pendingSends;

        TRACELINE(LoggingLevel::Verbose, partialReportedPropertiesString.c_str());

        if (_deviceClientHandle != NULL)
        {
            IOTHUB_CLIENT_RESULT result = IoTHubDeviceClient_LL_SendReportedState(_deviceClientHandle, (const unsigned char*)partialReportedPropertiesString.c_str(), partialReportedPropertiesString.size(), OnReportedStateSent, this);
            if (result != IOTHUB_CLIENT_OK)
            {
                throw DMException(DMSubsystem::IotHub, result, "IoTHubDeviceClient_LL_SendReportedState failed!");
            }
        }
        else if (_moduleClientHandle != NULL)
        {
            IOTHUB_CLIENT_RESULT result = IoTHubModuleClient_LL_SendReportedState(_moduleClientHandle, (const unsigned char*)partialReportedPropertiesString.c_str(), partialReportedPropertiesString.size(), OnReportedStateSent, this);
            if (result != IOTHUB_CLIENT_OK)
            {
                throw DMException(DMSubsystem::IotHub, result, "IoTHubModuleClient_LL_SendReportedState failed!");
            }
        }
    }

    void AzureRawHost::OnReportedStateSent(int status_code, void* userContextCallback)
    {
        AzureRawHost* This = static_cast<AzureRawHost*>(userContextCallback);
        This->OnReportedStateSent(status_code);
    }

    void AzureRawHost::SendEvent(
        const std::string& handlerId,
        const std::string& eventName,
        const Json::Value& messageData)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        LockGuard lk(&_azureSDKLock);

        IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;

        Json::Value message(messageData);
        std::string messageString = message.toStyledString();
        IOTHUB_MESSAGE_HANDLE messageHandle = IoTHubMessage_CreateFromString(messageString.c_str());
        if (messageHandle != NULL)
        {
            IoTHubMessage_SetContentTypeSystemProperty(messageHandle, "application%2fjson");
            IoTHubMessage_SetContentEncodingSystemProperty(messageHandle, "utf-8");

            IoTHubMessage_SetMessageId(messageHandle, eventName.c_str());

            MAP_HANDLE propMap = IoTHubMessage_Properties(messageHandle);
            Map_AddOrUpdate(propMap, "HandlerId", handlerId.c_str());
            Map_AddOrUpdate(propMap, "$$ContentType", "JSON");

            if (_deviceClientHandle != NULL)
            {
                result = IoTHubDeviceClient_LL_SendEventAsync(_deviceClientHandle, messageHandle, OnSendEventSent, this);
            }
            if (_moduleClientHandle != NULL)
            {
                result = IoTHubModuleClient_LL_SendEventAsync(_moduleClientHandle, messageHandle, OnSendEventSent, this);
            }

            IoTHubMessage_Destroy(messageHandle);
        }
        else
        {
            // Cannot throw exceptions here since we don't want to break the SDK loop.
            TRACELINE(LoggingLevel::Error, "Failed to create message.");
        }

        if (result != IOTHUB_CLIENT_OK)
        {
            // Cannot throw exceptions here since we don't want to break the SDK loop.
            TRACELINE(LoggingLevel::Error, "IoTHubDeviceClient_LL_SendEventAsync failed.");
        }
    }

    void AzureRawHost::OnDeviceTwinReceived(DEVICE_TWIN_UPDATE_STATE updateState, const unsigned char* payload, size_t size, void* userContextCallback)
    {
        AzureRawHost* This = static_cast<AzureRawHost*>(userContextCallback);
        This->OnDeviceTwinReceived(updateState, payload, size);
    }

    int AzureRawHost::OnDirectMethodInvoked(const char* methodName, const unsigned char* payload, size_t size, unsigned char** response, size_t* responseSize, void* userContextCallback)
    {
        AzureRawHost* This = static_cast<AzureRawHost*>(userContextCallback);
        return This->OnDirectMethodInvoked(methodName, payload, size, response, responseSize);
    }

    void AzureRawHost::OnSendEventSent(IOTHUB_CLIENT_CONFIRMATION_RESULT result, void* userContextCallback)
    {
        AzureRawHost* This = static_cast<AzureRawHost*>(userContextCallback);
        This->OnSendEventSent(result);
    }

    void AzureRawHost::OnSendEventSent(IOTHUB_CLIENT_CONFIRMATION_RESULT result)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        TRACELINEP(LoggingLevel::Verbose, "OnSendEventSent() - result: ", result);
    }

    void AzureRawHost::OnReportedStateSent(int statusCode)
    {
        (void)statusCode;
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        // ToDo: Temporary Synchronization
        _pendingSends--;
    }

    void AzureRawHost::MarkPending(const Json::Value& desiredProperties)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        Json::Value reportedProperties(Json::objectValue);

        // Go through the "desired" children and mark them pending...
        vector<string> keys = desiredProperties.getMemberNames();
        for (const string& key : keys)
        {
            RawHandlerMapType::const_iterator handlerIt = _rawHandlerMap.find(key);
            if (handlerIt == _rawHandlerMap.cend())
            {
                continue;
            }

            Json::Value desiredConfig = desiredProperties[key];
            if (desiredConfig.isNull() || !desiredConfig.isObject())
            {
                continue;
            }

            const string& handlerId = handlerIt->second->_rawHandler->GetId();

            try
            {
                // noexcept
                _reportedSectionsSummary->SetSectionStatus(handlerId, DeploymentStatus::ePending);

                handlerIt->second->_rawHandler->SetDeploymentStatus(DeploymentStatus::ePending);
                reportedProperties[handlerId] = handlerIt->second->_rawHandler->GetDeploymentStatusJson();
            }
            catch (...)
            {
                // noexcept
                _reportedSectionsSummary->SetSectionStatus(handlerId, DeploymentStatus::eUnknown);

                // indicate something went wrong...
                reportedProperties[handlerId] = MetaData::DeploymentStatusToJsonObject(DeploymentStatus::eUnknown);
            }
        }

        reportedProperties[_reportedSectionsSummary->GetId()] = _reportedSectionsSummary->ToJsonObject();
        ReportAll(reportedProperties);
    }

    InvokeHandlerResult AzureRawHost::InvokeHandler(
        const std::string& handlerId,
        const Json::Value& parametersJson)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        LockGuard lk(&_invokeLock);

        TRACELINEP(LoggingLevel::Verbose, "Looking for handler for: ", handlerId.c_str());

        InvokeHandlerResult invokeHandlerResult;
        // InvokeResult invokeResult(false);

        RawHandlerMapType::const_iterator handlerIt = _rawHandlerMap.find(handlerId);
        if (handlerIt == _rawHandlerMap.cend())
        {
            TRACELINE(LoggingLevel::Verbose, "Handler not found.");
            return invokeHandlerResult;
        }
        invokeHandlerResult.found = true;

        TRACELINEP(LoggingLevel::Verbose, "Found handler for: ", handlerId.c_str());

        if (handlerIt->second->_state == RawHandlerState::eInactive)
        {
            TRACELINE(LoggingLevel::Verbose, "Handler is inactive.");
            return invokeHandlerResult;
        }
        invokeHandlerResult.active = true;

        // Invoke does not throw. Any errors should have been already reported by now.
        invokeHandlerResult.invokeResult = handlerIt->second->_rawHandler->Invoke(parametersJson);
        return invokeHandlerResult;
    }

    void AzureRawHost::OnDeviceTwinReceived(DEVICE_TWIN_UPDATE_STATE updateState, const unsigned char* buffer, size_t size)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);
        TRACELINE(LoggingLevel::Verbose, "---- Desired Properties Start >> ----------------------------------------------------------------------");

        // Turn into a safe wide string...
        string payload((const char*)buffer, size);

        TRACELINEP(LoggingLevel::Verbose, "Received:", payload.c_str());

        // Parse the json and get the "desired" root...
        Json::Value root = JsonUtils::JsonObjectFromString(payload);

        Json::Value desiredProperties;

        // JsonObject^ desiredProperties;
        if (updateState == DEVICE_TWIN_UPDATE_COMPLETE)
        {
            TRACELINE(LoggingLevel::Verbose, "Entire device twin received.");

            if (JsonHelpers::HasKey(root, JsonDesired))
            {
                desiredProperties = root[JsonDesired];
            }
        }
        else
        {
            TRACELINE(LoggingLevel::Verbose, "Part of the device twin received.");
            desiredProperties = root;
        }

        // Go through the "desired" children and mark them pending...
        MarkPending(desiredProperties);

        // Go through the "desired" children and apply the desired changes...
        vector<string> keys = desiredProperties.getMemberNames();
        for (const string& key : keys)
        {
            TRACELINEP(LoggingLevel::Verbose, "Processing: ", key.c_str());
            InvokeHandlerResult result = InvokeHandler(key, desiredProperties[key]);
            if (result.found && result.active)
            {
                assert(!result.invokeResult.present);    // present == true is only for direct methods.
            }
        }

        TRACELINE(LoggingLevel::Verbose, "---- Desired Properties End << ------------------------------------------------------------------------");
    }

    int AzureRawHost::OnDirectMethodInvoked(const char* methodName, const unsigned char* payload, size_t size, unsigned char** response, size_t* responseSize)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);
        TRACELINE(LoggingLevel::Verbose, "---- Direct Method Start >> ---------------------------------------------------------------------------");

        int returnCode = JsonDirectMethodSuccessCode;
        string parameters((const char*)payload, size);

        TRACELINEP(LoggingLevel::Verbose, "Device Method Name:", methodName);
        TRACELINEP(LoggingLevel::Verbose, "Parameters        :", parameters.c_str());

        Json::Value parametersJson = JsonUtils::JsonObjectFromString(parameters);

        InvokeHandlerResult result = InvokeHandler(methodName, parametersJson);
        if (!result.found)
        {
            result.invokeResult.payload = "{ \"message\": \"Handler not found.\" }";
            result.invokeResult.code = JsonDirectMethodFailureCode;
        }
        else if (!result.active)
        {
            result.invokeResult.payload = "{ \"message\": \"Handler not active.\" }";
            result.invokeResult.code = JsonDirectMethodFailureCode;
        }
        else
        {
            assert(result.invokeResult.present);
        }

        TRACELINEP(LoggingLevel::Verbose, "Device Method Returned->payload: ", result.invokeResult.payload.c_str());
        TRACELINEP(LoggingLevel::Verbose, "Device Method Returned->code: ", result.invokeResult.code);

        // Prepare the return payload...
        *responseSize = result.invokeResult.payload.size();
        if ((*response = (unsigned char*)malloc(*responseSize)) == NULL)
        {
            returnCode = -1;
            result.invokeResult.payload = "Out of memory";  // This doesn't really go anywhere.
        }
        else
        {
            memcpy(*response, result.invokeResult.payload.c_str(), *responseSize);
            returnCode = result.invokeResult.code;
        }

        TRACELINE(LoggingLevel::Verbose, "---- Direct Method End << -----------------------------------------------------------------------------");

        return returnCode;
    }

    void AzureRawHost::LogDMException(
        const DMException& ex,
        const std::string& message,
        const std::string& param)
    {
        TRACELINEP(LoggingLevel::Error, message.c_str(), param.c_str());

        stringstream ss;
        ss << "Code: " << ex.Code() << " Message: " << ex.Message();
        TRACELINE(LoggingLevel::Error, ss.str().c_str());
    }

    void AzureRawHost::LogStdException(
        const std::exception& ex,
        const std::string& message,
        const std::string& param)
    {
        TRACELINEP(LoggingLevel::Error, message.c_str(), param.c_str());

        stringstream ss;
        ss << " Message: " << ex.what();
        TRACELINE(LoggingLevel::Error, ss.str().c_str());
    }

    void AzureRawHost::SignalStart()
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        for (auto& it : _rawHandlerMap)
        {
            TRACELINEP(LoggingLevel::Verbose, "Starting: ", it.first.c_str());

            const string& handlerId = it.second->_rawHandler->GetId();

            try
            {
                Json::Value handlerConfig = BuildHandlerConfig(handlerId);

                bool active = false;
                it.second->_rawHandler->Start(handlerConfig, active);
                it.second->_state = active ? RawHandlerState::eActive : RawHandlerState::eInactive;
            }
            catch (const DMException& ex)
            {
                LogDMException(ex, "An error occured while starting: ", handlerId.c_str());
            }
            catch (const exception& ex)
            {
                LogStdException(ex, "An error occured while starting: ", handlerId.c_str());
            }
            catch (...)
            {
                TRACELINEP(LoggingLevel::Error, "An error occured while starting: ", handlerId.c_str());
            }
        }
    }

    void AzureRawHost::SignalStop()
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        for (auto& it : _rawHandlerMap)
        {
            TRACELINEP(LoggingLevel::Verbose, "Stopping: ", it.first.c_str());
            it.second->_rawHandler->Stop();
        }
    }

    void AzureRawHost::SignalConnectionStatusChanged(
        ConnectionStatus status)
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        // ToDo: Temporary Synchronization
        if (status == ConnectionStatus::eOnline)
        {
            // Now, start accepting calls to the cloud...
            _connected = true;
        }

        for (auto& it : _rawHandlerMap)
        {
            TRACELINEP(LoggingLevel::Verbose, "Connection Status Changed: ", it.first.c_str());

            if (it.second->_state != RawHandlerState::eActive)
            {
                TRACELINE(LoggingLevel::Verbose, "Not active. Skipping...");
                continue;
            }

            const string& handleId = it.second->_rawHandler->GetId();

            try
            {
                it.second->_rawHandler->OnConnectionStatusChanged(status);
            }
            catch (const DMException& ex)
            {
                LogDMException(ex, "An error occured while starting: ", handleId.c_str());
            }
            catch (const exception& ex)
            {
                LogStdException(ex, "An error occured while starting: ", handleId.c_str());
            }
            catch (...)
            {
                TRACELINEP(LoggingLevel::Error, "An error occured while starting: ", handleId.c_str());
            }
        }

        // ToDo: Temporary Synchronization
        if (status == ConnectionStatus::eOffline)
        {
            // Now, start rejecting calls to the cloud...
            _connected = false;
        }
    }

    void AzureRawHost::DoWork()
    {
        if (_deviceClientHandle != NULL)
        {
            IoTHubDeviceClient_LL_DoWork(_deviceClientHandle);
        }
        if (_moduleClientHandle != NULL)
        {
            IoTHubModuleClient_LL_DoWork(_moduleClientHandle);
        }
    }

    void AzureRawHost::Destroy()
    {
        TRACELINE(LoggingLevel::Verbose, __FUNCTION__);

        // Finish any pending sends...
        while (_pendingSends != 0)
        {
            DoWork();
            ::Sleep(10);
        }

        if (_deviceClientHandle != NULL)
        {
            IoTHubDeviceClient_LL_Destroy(_deviceClientHandle);
            _deviceClientHandle = NULL;
        }
        if (_moduleClientHandle != NULL)
        {
            IoTHubModuleClient_LL_Destroy(_moduleClientHandle);
            _moduleClientHandle = NULL;
        }
    }

}}}}
