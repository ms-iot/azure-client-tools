#pragma once

#include "Utilities/Utils.h"
namespace DMUtils = Microsoft::Azure::DeviceManagement::Utils;

#include "device-agent/common/DMCommon.h"
namespace DMCommon = Microsoft::Azure::DeviceManagement::Common;

#include "AgentBinaryProxy.h"
#include "MdmServerProxy.h"
#include "PluginStub.h"
#include "RawHandlerHostProxy.h"
#include "RawHandlersStub.h"