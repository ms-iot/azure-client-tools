#pragma once

#include "AzureDeviceManagementCommon\DMCommon.h"
namespace DMCommon = Microsoft::Azure::DeviceManagement::Common;

#define $safeprojectname$Cmd1HandlerId "$safeprojectname$Cmd1Handler"

class $safeprojectname$Cmd1Handler : public DMCommon::BaseHandler
{
public:
    $safeprojectname$Cmd1Handler();

    // IRawHandler
    void Start(
        const Json::Value& config,
        bool& active);

    void OnConnectionStatusChanged(
        DMCommon::ConnectionStatus status);

    DMCommon::InvokeResult Invoke(
        const Json::Value& groupDesiredConfigJson) noexcept;
};